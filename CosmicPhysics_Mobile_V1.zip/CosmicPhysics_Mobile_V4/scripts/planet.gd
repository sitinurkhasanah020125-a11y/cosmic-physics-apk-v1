class_name CosmicPlanet
extends Node3D

var planet_name := "Planet"
var mass_solar := 0.000003
var radius_au := 0.0000426
var atmosphere := 1.0
var water := 0.7
var temperature_k := 288.0
var rotation_rate := 0.0
var rotation_axis := Vector3.UP
var weather := 0.0
var composition := "rocky"
var sim_pos := Vector3.ZERO
var sim_vel := Vector3.ZERO
var is_star := false
var texture_path := ""
var visual_radius := 0.3
var body_color := Color.WHITE
var density := 5.5
var crater_count := 0
var age := 0.0

var mesh_instance: MeshInstance3D
var atmosphere_mesh: MeshInstance3D
var ocean_mesh: MeshInstance3D
var cloud_mesh: MeshInstance3D
var collider: Area3D
var selected_ring: MeshInstance3D

func setup(data: Dictionary) -> void:
    planet_name = data.get("name", "Planet")
    mass_solar = data.get("mass", mass_solar)
    radius_au = data.get("radius", radius_au)
    atmosphere = data.get("atmosphere", 1.0)
    water = data.get("water", 0.0)
    temperature_k = data.get("temperature", 288.0)
    rotation_rate = data.get("rotation", 0.02)
    weather = data.get("weather", 0.0)
    composition = data.get("composition", "rocky")
    sim_pos = data.get("pos", Vector3.ZERO)
    sim_vel = data.get("vel", Vector3.ZERO)
    is_star = data.get("star", false)
    texture_path = data.get("texture", "")
    body_color = data.get("color", Color.WHITE)
    visual_radius = data.get("visual_radius", 0.3)
    density = data.get("density", density)
    build_visuals()
    update_visuals()

func build_visuals() -> void:
    mesh_instance = MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = visual_radius
    sphere.height = visual_radius * 2.0
    sphere.radial_segments = 48 if is_star else 32
    sphere.rings = 24 if is_star else 16
    mesh_instance.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    mat.roughness = 0.72 if not is_star else 0.25
    if texture_path != "":
        var tex = load(texture_path)
        if tex:
            mat.albedo_texture = tex
            mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    mat.albedo_color = body_color
    if is_star:
        mat.emission_enabled = true
        mat.emission = Color(1.0, 0.55, 0.12)
        mat.emission_energy_multiplier = 3.2
    mesh_instance.material_override = mat
    add_child(mesh_instance)

    collider = Area3D.new()
    collider.collision_layer = 2
    collider.collision_mask = 0
    var shape := CollisionShape3D.new()
    var sphere_shape := SphereShape3D.new()
    sphere_shape.radius = visual_radius
    shape.shape = sphere_shape
    collider.add_child(shape)
    add_child(collider)

    if not is_star:
        atmosphere_mesh = _shell(visual_radius * 1.075, Color(0.35,0.62,1.0,0.10), 24, 12)
        ocean_mesh = _shell(visual_radius * 1.006, Color(0.08,0.25,0.8,0.08), 24, 12)
        cloud_mesh = _shell(visual_radius * 1.025, Color(0.92,0.96,1.0,0.07), 24, 12)
        add_child(atmosphere_mesh); add_child(ocean_mesh); add_child(cloud_mesh)

func _shell(r: float, color: Color, seg: int, rings: int) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var s := SphereMesh.new(); s.radius=r; s.height=r*2.0; s.radial_segments=seg; s.rings=rings; node.mesh=s
    var m:=StandardMaterial3D.new(); m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; m.shading_mode=BaseMaterial3D.SHADING_MODE_PER_PIXEL; m.albedo_color=color; m.roughness=1.0; node.material_override=m
    return node

func set_selected(on: bool) -> void:
    if selected_ring == null:
        selected_ring = MeshInstance3D.new()
        var torus := TorusMesh.new(); torus.inner_radius=visual_radius*1.25; torus.outer_radius=visual_radius*1.32; torus.rings=32; torus.ring_segments=8; selected_ring.mesh=torus
        var m:=StandardMaterial3D.new(); m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED; m.albedo_color=Color(0.6,0.9,1.0,0.95); m.emission_enabled=true; m.emission=Color(0.2,0.55,1.0); m.emission_energy_multiplier=2.2; selected_ring.material_override=m; selected_ring.rotation.x=PI/2.0; add_child(selected_ring)
    selected_ring.visible=on

func update_visuals() -> void:
    position=sim_pos*20.0
    rotation += rotation_axis.normalized()*rotation_rate*0.016
    if atmosphere_mesh:
        atmosphere_mesh.visible=atmosphere>0.001
        var a:=atmosphere_mesh.material_override as StandardMaterial3D
        if a: a.albedo_color.a=clamp(0.02+atmosphere*0.10,0.0,0.14); atmosphere_mesh.scale=Vector3.ONE*(1.0+atmosphere*0.08)
    if ocean_mesh:
        ocean_mesh.visible=water>0.01
        var o:=ocean_mesh.material_override as StandardMaterial3D
        if o: o.albedo_color.a=clamp(0.015+water*0.08,0.0,0.10)
    if cloud_mesh:
        cloud_mesh.visible=atmosphere>0.05 and weather>0.02
        cloud_mesh.rotation.y += 0.0008+weather*0.001
