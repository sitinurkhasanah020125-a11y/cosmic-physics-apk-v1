extends Node3D

const G := 4.0 * PI * PI
const EARTH_RADIUS_AU := 4.2635e-5
const EARTH_MASS_SOLAR := 3.003e-6
const SAVE_DIR := "user://cosmic_physics/"
const GRAPHICS_OPTIONS := ["LOW", "240p", "360p", "480p", "720p", "1080p", "2K", "4K", "8K (ULTRA)"]

var bodies:Array[CosmicPlanet]=[]
var selected:CosmicPlanet
var sim_speed:=1.0
var paused:=false
var sim_time_days:=0.0
var camera:Camera3D
var camera_target:=Vector3.ZERO
var cam_distance:=52.0
var yaw:=-0.75
var pitch:=-0.28
var ui_info:Label
var speed_label:Label
var toast:Label
var atmosphere_label:Label
var mass_label:Label
var grav_label:Label
var temp_label:Label
var water_label:Label
var event_label:Label
var settings_layer:CanvasLayer
var game_layer:CanvasLayer
var graphics_index:=4
var physics_level:=5
var gravity_enabled:=true
var started:=false
var rng:=RandomNumberGenerator.new()
var event_log:Array[String]=[]
var collision_count:=0

func _ready()->void:
    rng.seed=1337
    _build_world(); _build_camera(); _build_start_menu()

func _build_world()->void:
    var env:=WorldEnvironment.new(); var e:=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_energy_multiplier=0.28; e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color(0.10,0.13,0.23); e.ambient_light_energy=0.25; e.tonemap_mode=Environment.TONE_MAPPER_FILMIC; env.environment=e; add_child(env)
    var sun_light:=DirectionalLight3D.new(); sun_light.light_energy=2.0; sun_light.shadow_enabled=false; sun_light.rotation_degrees=Vector3(-25,-35,0); add_child(sun_light)
    _build_starfield()

func _build_starfield()->void:
    var mm:=MultiMesh.new(); mm.transform_format=MultiMesh.TRANSFORM_3D; mm.instance_count=1400
    var mesh:=SphereMesh.new(); mesh.radius=0.035; mesh.height=0.07; mesh.radial_segments=4; mesh.rings=2
    var mat:=StandardMaterial3D.new(); mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED; mat.emission_enabled=true; mat.emission=Color(0.9,0.95,1.0); mat.emission_energy_multiplier=2.0; mesh.material=mat; mm.mesh=mesh
    var sf:=MultiMeshInstance3D.new(); sf.multimesh=mm
    for i in mm.instance_count:
        var dir:=Vector3(rng.randf_range(-1,1),rng.randf_range(-.75,.75),rng.randf_range(-1,1)).normalized(); mm.set_instance_transform(i,Transform3D(Basis.IDENTITY,dir*rng.randf_range(120,350)))
    add_child(sf)

func _build_camera()->void:
    camera=Camera3D.new(); camera.current=true; camera.fov=55.0; add_child(camera)

func _build_start_menu()->void:
    settings_layer=CanvasLayer.new(); add_child(settings_layer)
    var bg:=ColorRect.new(); bg.color=Color(0.015,0.02,0.05,0.97); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); settings_layer.add_child(bg)
    var panel:=PanelContainer.new(); panel.position=Vector2(70,40); panel.size=Vector2(1140,640); bg.add_child(panel)
    var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",10); panel.add_child(box)
    var title:=Label.new(); title.text="COSMIC PHYSICS MOBILE V4"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",30); box.add_child(title)
    var sub:=Label.new(); sub.text="Pilih kualitas grafik dan fisika sebelum mulai"; sub.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(sub)
    var gt:=Label.new(); gt.text="GRAFIK"; gt.add_theme_font_size_override("font_size",20); box.add_child(gt)
    var go:=OptionButton.new(); go.custom_minimum_size=Vector2(0,50); go.selected=graphics_index; for x in GRAPHICS_OPTIONS:
        go.add_item(x)
    go.item_selected.connect(func(i): graphics_index=i)
    box.add_child(go)
    var pt:=Label.new(); pt.text="FISIKA"; pt.add_theme_font_size_override("font_size",20); box.add_child(pt)
    var sl:=HSlider.new(); sl.min_value=1; sl.max_value=10; sl.step=1; sl.value=physics_level; sl.custom_minimum_size=Vector2(0,55); box.add_child(sl)
    var pl:=Label.new(); pl.text="Fisika: %d / 10"%physics_level; pl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(pl); sl.value_changed.connect(func(v):physics_level=int(v); pl.text="Fisika: %d / 10"%physics_level)
    var hint:=Label.new(); hint.text="1 = paling ringan • 10 = paling detail\n2K/4K/8K adalah target kualitas render, bukan memaksa layar HP menjadi 2K/4K/8K."; hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(hint)
    var start:=Button.new(); start.text="MULAI SIMULASI"; start.custom_minimum_size=Vector2(0,60); start.pressed.connect(_start_simulation); box.add_child(start)

func _start_simulation()->void:
    settings_layer.queue_free(); started=true; _build_ui(); _spawn_initial_system(); _select_body(bodies[3]); _apply_quality(); _update_camera(); _show_toast("Grafik %s / Fisika %d"%[GRAPHICS_OPTIONS[graphics_index],physics_level])

func _apply_quality()->void:
    var scale_map=[0.55,0.55,0.65,0.75,0.85,1.0,1.0,1.0,1.0]
    get_viewport().scaling_3d_scale=scale_map[graphics_index]

func _spawn_initial_system()->void:
    var specs=[
        {"name":"Sun","mass":1.0,"radius":0.00465,"atmosphere":0.0,"water":0.0,"temperature":5778.0,"pos":Vector3.ZERO,"vel":Vector3.ZERO,"star":true,"texture":"res://assets/planets/sun.png","color":Color(1,.75,.25),"visual_radius":3.15},
        {"name":"Mercury","mass":1.660e-7,"radius":1.633e-5,"atmosphere":.02,"water":0.0,"temperature":440.0,"a":.387,"texture":"res://assets/planets/mercury.png","color":Color(.6,.55,.5),"visual_radius":.23},
        {"name":"Venus","mass":2.447e-6,"radius":4.045e-5,"atmosphere":.96,"water":0.0,"temperature":737.0,"weather":.9,"a":.723,"texture":"res://assets/planets/venus.png","color":Color(.95,.72,.38),"visual_radius":.39},
        {"name":"Earth","mass":EARTH_MASS_SOLAR,"radius":EARTH_RADIUS_AU,"atmosphere":1.0,"water":.71,"temperature":288.0,"weather":.65,"rotation":.035,"a":1.0,"texture":"res://assets/planets/earth.png","color":Color(.3,.6,1),"visual_radius":.42},
        {"name":"Mars","mass":3.227e-7,"radius":2.267e-5,"atmosphere":.08,"water":.01,"temperature":210.0,"weather":.25,"a":1.524,"texture":"res://assets/planets/mars.png","color":Color(.75,.32,.22),"visual_radius":.30},
        {"name":"Jupiter","mass":9.545e-4,"radius":4.779e-4,"atmosphere":1.0,"water":0.0,"temperature":165.0,"weather":1.0,"a":5.203,"texture":"res://assets/planets/jupiter.png","color":Color(.83,.70,.53),"visual_radius":.98},
        {"name":"Saturn","mass":2.858e-4,"radius":4.025e-4,"atmosphere":1.0,"water":0.0,"temperature":134.0,"weather":.9,"a":9.537,"texture":"res://assets/planets/saturn.png","color":Color(.88,.76,.54),"visual_radius":.84},
        {"name":"Uranus","mass":4.366e-5,"radius":1.706e-4,"atmosphere":1.0,"water":0.0,"temperature":76.0,"weather":.4,"a":19.19,"texture":"res://assets/planets/uranus.png","color":Color(.45,.82,.88),"visual_radius":.59},
        {"name":"Neptune","mass":5.151e-5,"radius":1.655e-4,"atmosphere":1.0,"water":0.0,"temperature":72.0,"weather":.7,"a":30.07,"texture":"res://assets/planets/neptune.png","color":Color(.25,.35,.95),"visual_radius":.59},
        {"name":"Pluto","mass":6.56e-9,"radius":7.93e-6,"atmosphere":.02,"water":.05,"temperature":44.0,"a":39.48,"texture":"res://assets/planets/mars.png","color":Color(.65,.55,.48),"visual_radius":.18}
    ]
    for d in specs:
        if d.has("a"): d["pos"]=Vector3(d["a"],rng.randf_range(-.003,.003),0); d["vel"]=Vector3(0,0,2*PI/sqrt(d["a"]))
        var p:=CosmicPlanet.new(); add_child(p); p.setup(d); bodies.append(p)
        if p.planet_name=="Saturn":_add_saturn_rings(p)
    _spawn_moons(); _spawn_asteroid_belt()

func _spawn_moons()->void:
    _make_moon("Moon",bodies[3],.012,3e-8,4e-6,0.0); _make_moon("Phobos",bodies[4],.00016,5e-11,1e-6,.7); _make_moon("Deimos",bodies[4],.0004,1e-11,1.5e-6,.3)
func _make_moon(n:String,parent:CosmicPlanet,dist:float,mass:float,radius:float,phase:float)->void:
    var p:=CosmicPlanet.new(); add_child(p); var pos:=parent.sim_pos+Vector3(cos(phase),0,sin(phase))*dist; var v:=sqrt(max(.000001,G*parent.mass_solar/dist)); p.setup({"name":n,"mass":mass,"radius":radius,"atmosphere":0,"water":.05,"temperature":220,"pos":pos,"vel":parent.sim_vel+Vector3(0,0,v),"texture":"res://assets/planets/moon/albedo.jpg","color":Color(.6,.6,.6),"visual_radius":.10}); bodies.append(p)
func _spawn_asteroid_belt()->void:
    var count:=10+physics_level*12
    for i in count:
        var a:=rng.randf_range(2.2,3.2); var ang:=rng.randf_range(0,TAU); var pos:=Vector3(cos(ang)*a,rng.randf_range(-.015,.015),sin(ang)*a); var vel:=Vector3(-sin(ang),0,cos(ang))*(2*PI/sqrt(a)); var p:=CosmicPlanet.new(); add_child(p); p.setup({"name":"Asteroid %03d"%i,"mass":rng.randf_range(1e-10,5e-9),"radius":rng.randf_range(1e-6,5e-6),"temperature":180,"pos":pos,"vel":vel,"texture":"res://assets/planets/asteroid.png","color":Color(.45,.42,.38),"visual_radius":rng.randf_range(.035,.07)}); bodies.append(p)
func _add_saturn_rings(p:CosmicPlanet)->void:
    var ring:=MeshInstance3D.new(); var t:=TorusMesh.new(); t.inner_radius=p.visual_radius*1.35; t.outer_radius=p.visual_radius*2.15; t.ring_segments=64; t.rings=2; ring.mesh=t; var m:=StandardMaterial3D.new(); m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; m.albedo_color=Color(.78,.72,.58,.55); ring.material_override=m; ring.rotation.x=.42; p.add_child(ring)

func _build_ui()->void:
    game_layer=CanvasLayer.new(); add_child(game_layer); var panel:=PanelContainer.new(); panel.position=Vector2(14,14); panel.size=Vector2(430,680); game_layer.add_child(panel); var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",5); panel.add_child(box)
    var title:=Label.new(); title.text="COSMIC PHYSICS MOBILE V4"; title.add_theme_font_size_override("font_size",21); box.add_child(title)
    ui_info=Label.new(); box.add_child(ui_info); grav_label=Label.new(); box.add_child(grav_label); atmosphere_label=Label.new(); box.add_child(atmosphere_label); mass_label=Label.new(); box.add_child(mass_label); temp_label=Label.new(); box.add_child(temp_label); water_label=Label.new(); box.add_child(water_label)
    var r:=HBoxContainer.new(); box.add_child(r); _button(r,"Pause",Callable(self,"_toggle_pause")); _button(r,"Reset",Callable(self,"_reset_system")); _button(r,"Gravitasi",Callable(self,"_toggle_gravity"))
    speed_label=Label.new(); box.add_child(speed_label); var sp:=HBoxContainer.new(); box.add_child(sp); for s in [0.1,1.0,10.0,100.0,1000.0]:
        _button(sp,str(s)+"x",Callable(self,"_set_speed").bind(s))
    var a:=HBoxContainer.new(); box.add_child(a); _button(a,"-Atmos",Callable(self,"_change_atmosphere").bind(-.25)); _button(a,"+Atmos",Callable(self,"_change_atmosphere").bind(.25)); _button(a,"Air Loss",Callable(self,"_atmos_loss"))
    var b:=HBoxContainer.new(); box.add_child(b); _button(b,"-10% M",Callable(self,"_change_mass").bind(.9)); _button(b,"+10% M",Callable(self,"_change_mass").bind(1.1)); _button(b,"-10% R",Callable(self,"_change_radius").bind(.9)); _button(b,"+10% R",Callable(self,"_change_radius").bind(1.1))
    var c:=HBoxContainer.new(); box.add_child(c); _button(c,"Nudge",Callable(self,"_nudge_selected")); _button(c,"Impact",Callable(self,"_launch_impact")); _button(c,"Destroy",Callable(self,"_destroy_selected"))
    var d:=HBoxContainer.new(); box.add_child(d); _button(d,"Planet +",Callable(self,"_create_planet")); _button(d,"Asteroid +",Callable(self,"_spawn_asteroid")); _button(d,"Moon +",Callable(self,"_create_moon"))
    var e:=HBoxContainer.new(); box.add_child(e); _button(e,"Save",Callable(self,"_save_sim")); _button(e,"Load",Callable(self,"_load_sim")); _button(e,"Log",Callable(self,"_show_log"))
    event_label=Label.new(); event_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(event_label); var help:=Label.new(); help.text="Tap objek • drag untuk orbit • pinch/wheel untuk zoom\nV4: atmosfer, laut, suhu, bulan, asteroid belt, collision, fragmentasi."; help.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(help)
    toast=Label.new(); toast.position=Vector2(460,20); toast.size=Vector2(760,45); toast.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; toast.add_theme_font_size_override("font_size",18); game_layer.add_child(toast)
func _button(parent:Container,text:String,cb:Callable)->void:
    var b:=Button.new(); b.text=text; b.custom_minimum_size=Vector2(0,38); b.pressed.connect(cb); parent.add_child(b)

func _physics_process(delta:float)->void:
    if not started:return
    if not paused:
        var substeps:=clampi(1+physics_level/3+int(sim_speed>50)+int(sim_speed>500),1,8); var dt:=delta*sim_speed*3.0/365.25/float(substeps); for i in substeps:_step_physics(dt); sim_time_days+=delta*sim_speed*3.0
    for p in bodies:
        if is_instance_valid(p):_update_planet_environment(p);p.age+=delta*sim_speed;p.update_visuals()
    _update_camera();_refresh_ui()
func _update_planet_environment(p:CosmicPlanet)->void:
    if p.is_star:return
    var d:float=maxf(p.sim_pos.length(),0.05); var eq:float=278.0/sqrt(d); p.temperature_k=lerp(p.temperature_k,eq*(1.0-.15*p.water)+45.0,.002*physics_level); p.weather=clamp(p.atmosphere*(.3+abs(sin(p.age*.0005))*.7),0,1)
    if physics_level>=6 and p.temperature_k>900:p.atmosphere=max(0,p.atmosphere-.000001*physics_level)
func _step_physics(dt:float)->void:
    if gravity_enabled:
        var accs:Array[Vector3]=[];accs.resize(bodies.size())
        for i in bodies.size():
            var ai:=Vector3.ZERO;var pi:=bodies[i]
            if not is_instance_valid(pi):accs[i]=ai;continue
            for j in bodies.size():
                if i==j:continue
                var pj:=bodies[j];if not is_instance_valid(pj):continue
                var r:Vector3=pj.sim_pos-pi.sim_pos;var d2:float=maxf(r.length_squared(),1e-10);ai+=G*pj.mass_solar*r/pow(d2,1.5)
            accs[i]=ai
        for i in bodies.size():
            if is_instance_valid(bodies[i]):bodies[i].sim_vel+=accs[i]*dt
    for p in bodies:
        if is_instance_valid(p):p.sim_pos+=p.sim_vel*dt
    _resolve_collisions()
func _resolve_collisions()->void:
    var dead:Array[CosmicPlanet]=[]
    for i in bodies.size():
        var a:=bodies[i];if not is_instance_valid(a):continue
        for j in range(i+1,bodies.size()):
            var b:=bodies[j];if not is_instance_valid(b):continue
            if a.sim_pos.distance_to(b.sim_pos)<=a.radius_au+b.radius_au:
                collision_count+=1;var rv:float=(a.sim_vel-b.sim_vel).length();var energy:float=0.5*(a.mass_solar*b.mass_solar/maxf(a.mass_solar+b.mass_solar,1e-12))*rv*rv
                if a.is_star or b.is_star:
                    var doomed:=b if a.is_star else a;_fragment_body(doomed,energy,physics_level+2);dead.append(doomed)
                elif physics_level>=5 and energy>2e-10*physics_level:
                    _fragment_body(a,energy,max(3,physics_level));_fragment_body(b,energy,max(3,physics_level));dead.append(b);_log("TABRAKAN KERAS %s ↔ %s | E %.3e"%[a.planet_name,b.planet_name,energy])
                else:
                    var winner:=a if a.mass_solar>=b.mass_solar else b;var loser:=b if winner==a else a;_merge_planets(winner,loser);dead.append(loser)
    for p in dead:
        if is_instance_valid(p):bodies.erase(p);p.queue_free()
func _merge_planets(a:CosmicPlanet,b:CosmicPlanet)->void:
    var total:=a.mass_solar+b.mass_solar;a.sim_pos=(a.sim_pos*a.mass_solar+b.sim_pos*b.mass_solar)/total;a.sim_vel=(a.sim_vel*a.mass_solar+b.sim_vel*b.mass_solar)/total;a.atmosphere=clamp((a.atmosphere*a.mass_solar+b.atmosphere*b.mass_solar)/total,0,1);a.water=clamp((a.water*a.mass_solar+b.water*b.mass_solar)/total,0,1);a.mass_solar=total;a.radius_au=pow(pow(a.radius_au,3)+pow(b.radius_au,3),1.0/3.0);a.visual_radius=clamp(.30*sqrt(a.radius_au/EARTH_RADIUS_AU),.12,2.3);_resize_selected();_log("MERGER: %s + %s"%[a.planet_name,b.planet_name])
func _fragment_body(p:CosmicPlanet,energy:float,count:int)->void:
    if p.is_star:return
    p.crater_count+=max(1,int(energy*1e7));p.mass_solar*=clamp(.35+.04*physics_level,.35,.75);p.atmosphere=max(0,p.atmosphere-(.12+.03*physics_level));p.water=max(0,p.water-(.08+.02*physics_level))
    for k in count:
        var ang:=rng.randf_range(0,TAU);var dir:=Vector3(cos(ang),rng.randf_range(-.7,.7),sin(ang)).normalized();var q:=CosmicPlanet.new();add_child(q);q.setup({"name":"Fragment","mass":max(p.mass_solar*.02/float(count),1e-12),"radius":max(2e-6,p.radius_au*.08),"temperature":p.temperature_k,"pos":p.sim_pos+dir*max(p.radius_au*8,.0005),"vel":p.sim_vel+dir*rng.randf_range(1,8)*(1+physics_level*.15),"texture":"res://assets/planets/asteroid.png","color":Color(.45,.4,.35),"visual_radius":rng.randf_range(.045,.10)});bodies.append(q)
    _log("FRAGMENTASI %s menjadi %d bagian | E %.3e"%[p.planet_name,count,energy])
func _create_planet()->void:
    var base:Vector3=selected.sim_pos if selected else Vector3(2,0,0);var dir:Vector3=Vector3(rng.randf_range(-1,1),rng.randf_range(-0.25,0.25),rng.randf_range(-1,1)).normalized();var pos:Vector3=base+dir*0.35;var a:float=maxf(pos.length(),0.5);var p:=CosmicPlanet.new();add_child(p);p.setup({"name":"Experiment Planet","mass":EARTH_MASS_SOLAR,"radius":EARTH_RADIUS_AU,"atmosphere":.7,"water":.6,"temperature":288,"weather":.5,"pos":pos,"vel":Vector3(0,0,2*PI/sqrt(a)),"texture":"res://assets/planets/earth.png","color":Color(.3,.6,1),"visual_radius":.42});bodies.append(p);_select_body(p)
func _create_moon()->void:
    if selected==null or selected.is_star:return
    _make_moon("Custom Moon",selected,.015,1e-9,2e-6,rng.randf_range(0,TAU))
func _spawn_asteroid()->void:
    var target:=selected.sim_pos if selected else Vector3.ZERO;var dir:=Vector3(rng.randf_range(-1,1),rng.randf_range(-.2,.2),rng.randf_range(-1,1)).normalized();var start:=target+dir*.20;var p:=CosmicPlanet.new();add_child(p);p.setup({"name":"Asteroid","mass":1e-8,"radius":3e-6,"temperature":180,"pos":start,"vel":(selected.sim_vel if selected else Vector3.ZERO)+(target-start).normalized()*18,"texture":"res://assets/planets/asteroid.png","color":Color(.4,.4,.4),"visual_radius":.11});bodies.append(p)
func _launch_impact()->void:
    if selected==null:return
    var p:=CosmicPlanet.new();add_child(p);var start:=selected.sim_pos+Vector3(.18,0,.03);p.setup({"name":"Impact projectile","mass":3e-8,"radius":1.2e-5,"temperature":400,"pos":start,"vel":selected.sim_vel+(selected.sim_pos-start).normalized()*30,"texture":"res://assets/planets/asteroid.png","color":Color(.45,.45,.45),"visual_radius":.16});bodies.append(p)
func _change_atmosphere(amount:float)->void:
    if selected==null or selected.is_star:return
    selected.atmosphere=clamp(selected.atmosphere+amount,0,1)
func _atmos_loss()->void:
    if selected==null or selected.is_star:return
    selected.atmosphere=max(0,selected.atmosphere-.35);selected.water=max(0,selected.water-.08)
func _change_mass(mult:float)->void:
    if selected!=null:selected.mass_solar=clamp(selected.mass_solar*mult,1e-12,10)
func _change_radius(mult:float)->void:
    if selected!=null:selected.radius_au=clamp(selected.radius_au*mult,1e-7,2);selected.visual_radius=clamp(selected.visual_radius*mult,.03,3.5);_resize_selected()
func _resize_selected()->void:
    if selected!=null and selected.mesh_instance:
        var s:=selected.mesh_instance.mesh as SphereMesh;s.radius=selected.visual_radius;s.height=selected.visual_radius*2
func _nudge_selected()->void:
    if selected!=null:selected.sim_vel+=Vector3(.8,0,.8)
func _destroy_selected()->void:
    if selected==null or selected.is_star:return
    var dead:=selected;bodies.erase(dead);selected=null;_fragment_body(dead,dead.mass_solar*.01,max(6,physics_level+4));dead.queue_free()

func _save_sim()->void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SAVE_DIR));var data:Array=[]
    for p in bodies:
        if is_instance_valid(p):data.append({"name":p.planet_name,"mass":p.mass_solar,"radius":p.radius_au,"atmosphere":p.atmosphere,"water":p.water,"temperature":p.temperature_k,"pos":p.sim_pos,"vel":p.sim_vel,"visual_radius":p.visual_radius,"texture":p.texture_path,"star":p.is_star,"color":p.body_color})
    var f:=FileAccess.open(SAVE_DIR+"slot1.json",FileAccess.WRITE);f.store_string(JSON.stringify({"sim_time":sim_time_days,"bodies":data,"graphics":graphics_index,"physics":physics_level}));f.close();_show_toast("Simulasi tersimpan")
func _load_sim()->void:
    var path:=SAVE_DIR+"slot1.json";if not FileAccess.file_exists(path):_show_toast("Belum ada save");return
    var f:=FileAccess.open(path,FileAccess.READ);var parsed=JSON.parse_string(f.get_as_text());f.close();if parsed==null:return
    for p in bodies:
        if is_instance_valid(p):p.queue_free()
    bodies.clear();sim_time_days=parsed.get("sim_time",0)
    for d in parsed.get("bodies",[]):var p:=CosmicPlanet.new();add_child(p);p.setup(d);bodies.append(p)
    _select_body(bodies[0] if bodies.size()>0 else null);_show_toast("Simulasi dimuat")
func _show_log()->void:_show_toast("Tumbukan: %d | Event terakhir: %s"%[collision_count,(event_log[-1] if event_log.size()>0 else "-")])
func _log(msg:String)->void:event_log.append("[%d hari] %s"%[int(sim_time_days),msg]);if event_log.size()>20:event_log.pop_front()
func _show_toast(msg:String)->void:
    if toast:toast.text=msg;get_tree().create_timer(2.0).timeout.connect(func():if is_instance_valid(toast):toast.text="")
func _select_body(p:CosmicPlanet)->void:
    for x in bodies:
        if is_instance_valid(x):x.set_selected(x==p)
    selected=p
func _set_speed(v:float)->void:sim_speed=v
func _toggle_pause()->void:paused=!paused;_show_toast("PAUSE" if paused else "SIMULASI LANJUT")
func _toggle_gravity()->void:gravity_enabled=!gravity_enabled
func _reset_system()->void:get_tree().reload_current_scene()
func _refresh_ui()->void:
    speed_label.text="Kecepatan: %sx | Hari: %d | Fisika: %d"%[str(sim_speed),int(sim_time_days),physics_level];grav_label.text="Gravitasi: "+("AKTIF" if gravity_enabled else "NONAKTIF")
    if selected and is_instance_valid(selected):
        ui_info.text="Dipilih: %s\nJarak %.3f AU | Kecepatan %.3f AU/tahun"%[selected.planet_name,selected.sim_pos.length(),selected.sim_vel.length()];atmosphere_label.text="Atmosfer: %d%%"%int(selected.atmosphere*100);mass_label.text="Massa: %.3e M☉"%selected.mass_solar;temp_label.text="Suhu: %.1f K / %.1f °C"%[selected.temperature_k,selected.temperature_k-273.15];water_label.text="Laut/Air: %d%%"%int(selected.water*100)
    event_label.text="Event: %d tumbukan\n"%collision_count+"\n".join(event_log.slice(max(0,event_log.size()-3),event_log.size()))
func _input(event:InputEvent)->void:
    if not started:return
    if event is InputEventMouseButton:
        if event.button_index==MOUSE_BUTTON_LEFT and event.pressed:_pick_body(event.position)
        elif event.button_index==MOUSE_BUTTON_WHEEL_UP and event.pressed:cam_distance=max(3,cam_distance*.86)
        elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN and event.pressed:cam_distance=min(600,cam_distance*1.16)
    elif event is InputEventScreenTouch and event.pressed:_pick_body(event.position)
    elif event is InputEventScreenDrag:
        yaw-=event.relative.x*.004;pitch=clamp(pitch-event.relative.y*.003,-1.35,1.35)
func _pick_body(pos:Vector2)->void:
    var origin:=camera.project_ray_origin(pos);var dir:=camera.project_ray_normal(pos).normalized();var best:CosmicPlanet=null;var bt:=INF
    for p in bodies:
        if not is_instance_valid(p):continue
        var c:Vector3=p.position;var t:float=maxf(0.0,(c-origin).dot(dir));var closest:Vector3=origin+dir*t
        if closest.distance_to(c)<=p.visual_radius*1.45 and t<bt:best=p;bt=t
    if best:_select_body(best)
func _update_camera()->void:
    if selected and is_instance_valid(selected):camera_target=selected.position
    var cp:=cos(pitch);var sp:=sin(pitch);var cy:=cos(yaw);var sy:=sin(yaw);camera.global_position=camera_target+Vector3(cp*cy,sp,cp*sy)*cam_distance;camera.look_at(camera_target,Vector3.UP)
