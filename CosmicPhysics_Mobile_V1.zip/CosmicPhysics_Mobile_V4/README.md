# Cosmic Physics Mobile V4

Godot 4.x mobile solar-system sandbox.

## Start menu
- Grafik: LOW, 240p, 360p, 480p, 720p, 1080p, 2K, 4K, 8K (ULTRA)
- Fisika: 1-10

Grafik 2K/4K/8K adalah target kualitas/render internal. Layar HP tidak dipaksa menjadi resolusi fisik tersebut.

## V4
- N-body gravity
- impact energy, collision response, merger, deformation approximation and large fragments
- atmosphere controls and atmospheric-loss experiment
- surface temperature driven by distance to star
- water/ocean amount, cloud/weather approximation
- planet rotation
- Earth Moon, Mars moons, Pluto
- individual asteroid-belt bodies scaled by physics level
- manual mass/radius controls
- create planet/moon/asteroid and projectile impacts
- crater/ejecta approximation
- save/load simulation slots
- event log and planet statistics
- mobile free camera and extreme zoom

This remains a mobile-friendly approximation, not a scientific SPH/hydrodynamic solver.
Recommended for vivo Y21d: 720p + Physics 4-6.
